from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.ensemble import RandomForestClassifier


# All sklearn Transforms must have the `transform` and `fit` methods
class DropColumns(BaseEstimator, TransformerMixin):
    def __init__(self, columns):
        self.columns = columns

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        # Primeiro realizamos a cópia do dataframe 'X' de entrada
        data = X.copy()
        # Retornamos um novo dataframe sem as colunas indesejadas
        return data.drop(labels=self.columns, axis='columns')

df_data_1.loc[df_data_3.NOTA_MF > 10.0, 'NOTA_MF'] = 10.0

df_data_1['REPROVACOES_DE'] = df_data_3['REPROVACOES_DE'].values.astype(np.float64)
df_data_1['REPROVACOES_EM'] = df_data_3['REPROVACOES_EM'].values.astype(np.float64)
df_data_1['REPROVACOES_MF'] = df_data_3['REPROVACOES_MF'].values.astype(np.float64)
df_data_1['REPROVACOES_GO'] = df_data_3['REPROVACOES_GO'].values.astype(np.float64)
df_data_1['H_AULA_PRES'] = df_data_3['H_AULA_PRES'].values.astype(np.float64)
df_data_1['TAREFAS_ONLINE'] = df_data_3['TAREFAS_ONLINE'].values.astype(np.float64)
df_data_1['FALTAS'] = df_data_3['FALTAS'].values.astype(np.float64)
df_data_1.dtypes

df_data_1= RandomForestClassifier(random_state=17000, criterion='gini', max_depth=7.9,  max_features=11, n_estimators= 50)